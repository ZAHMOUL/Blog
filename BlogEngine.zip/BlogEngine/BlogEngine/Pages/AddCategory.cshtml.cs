using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlogEngine.Models;
using BlogEngine.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogEngine.Pages
{
    public class AddCategoryModel : PageModel
    {
        private readonly ICategoryRepository _categoryRepository;

        public AddCategoryModel(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        [BindProperty]
        public Category Category { get; set; }

        public async Task<IActionResult> OnPost()
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var addedCategory = await _categoryRepository.AddCategoryAsync(Category);
                    return RedirectToPage("Blog"); // Redirect to the blog page
                }
                catch (InvalidOperationException ex)
                {
                    ModelState.AddModelError(string.Empty, ex.Message); // Add the error to ModelState
                    return Page(); // Return to the same page
                }
                catch (Exception ex)
                {
                }
            }

            // If there's an error or validation issue, return to the same page
            return Page();
        }

    }


}
