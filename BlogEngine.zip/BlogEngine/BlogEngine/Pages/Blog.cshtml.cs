using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlogEngine.Models;
using BlogEngine.Repository;
using BlogEngine.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogEngine.Pages
{
    public class BlogModel : PageModel
    {
        private readonly IBlogRepository _blogRepository;

        public BlogModel(IBlogRepository blogRepository)
        {
            _blogRepository = blogRepository;
        }

        public List<Category> Categories { get; set; }
        public List<Post> Posts { get; set; }

        public async Task OnGet()
        {
            // Retrieve a list of categories and posts using your BlogRepository
            Categories = await _blogRepository.GetCategoriesAsync();
            Posts = await _blogRepository.GetPostsAsync();
        }
    }
}
