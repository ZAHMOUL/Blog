using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BlogEngine.Models;
using BlogEngine.Repository;
using BlogEngine.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogEngine.Pages
{
    public class AddPostModel : PageModel
    {
        private readonly ICategoryRepository _categoryRepository;
        private readonly IPostRepository _postRepository;

        public AddPostModel(ICategoryRepository categoryRepository, IPostRepository postRepository)
        {
            _categoryRepository = categoryRepository;
            _postRepository = postRepository;
        }

        [BindProperty]
        public Post Post { get; set; }


        [BindProperty]
        public List<Category> Categories { get; set; }

        [BindProperty]
        [Display(Name = "Category")]
        public int CategoryId { get; set; }

        public async Task OnGet()
        {
            Categories = (List<Category>)await _categoryRepository.GetCategoriesAsync();
        }

        public async Task<IActionResult> OnPost()
        {

            if (CategoryId == -1)
            {
                ModelState.AddModelError(nameof(CategoryId), "Category is required");
                Categories = (List<Category>)await _categoryRepository.GetCategoriesAsync();
                return Page();
            }

            if (!ModelState.IsValid)
            {
                Categories = (List<Category>)await _categoryRepository.GetCategoriesAsync();
                return Page();
            }

            // Check for duplicate post title
            var existingPosts = await _postRepository.GetPostsAsync();
            var duplicatePost = existingPosts.Find(p =>
                string.Equals(p.Title.Trim(), Post.Title.Trim(), StringComparison.OrdinalIgnoreCase));

            if (duplicatePost != null)
            {
                ModelState.AddModelError("Post.Title", "A post with the same title already exists.");
                Categories = (List<Category>)await _categoryRepository.GetCategoriesAsync();
                return Page();
            }

            await _postRepository.AddPostAsync(Post);

            return RedirectToPage("Blog");
        }
    }
}
