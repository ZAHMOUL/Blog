using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlogEngine.Models;
using BlogEngine.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogEngine.Pages
{
    public class EditPostModel : PageModel
    {
        private readonly IPostRepository _postRepository;
        private readonly ICategoryRepository _categoryRepository;

        public EditPostModel(IPostRepository postRepository, ICategoryRepository categoryRepository)
        {
            _postRepository = postRepository;
            _categoryRepository = categoryRepository;
        }

        [BindProperty]
        public Post Post { get; set; }

        public List<Category> Categories { get; set; }

        public async Task OnGet(int id)
        {
            Categories = (List<Category>)await _categoryRepository.GetCategoriesAsync();
            Post = await _postRepository.GetPostAsync(id);
        }

        public async Task<IActionResult> OnPost()
        {
            // Check if the ModelState is not valid (validation errors)
            if (!ModelState.IsValid)
            {
                Categories = (List<Category>)await _categoryRepository.GetCategoriesAsync();
                return Page();
            }

            // Check if CategoryId is -1 (indicating no category selected)
            if (Post.CategoryId == -1)
            {
                Categories = (List<Category>)await _categoryRepository.GetCategoriesAsync();
                ModelState.AddModelError("Post.CategoryId", "Category is required.");
                return Page();
            }

            // Check for duplicate post titles
            var existingPosts = await _postRepository.GetPostsAsync();
            var duplicateTitle = existingPosts.FirstOrDefault(p =>
                string.Equals(p.Title.Trim(), Post.Title.Trim(), StringComparison.OrdinalIgnoreCase) && p.PostId != Post.PostId);

            if (duplicateTitle != null)
            {
                Categories = (List<Category>)await _categoryRepository.GetCategoriesAsync();
                ModelState.AddModelError("Post.Title", "A post with the same title already exists.");
                return Page();
            }

            try
            {
                // Retrieve the existing post by its ID
                var existingPost = await _postRepository.GetPostAsync(Post.PostId);

                if (existingPost == null)
                {
                    // Handle the case where the post does not exist
                    return NotFound();
                }

                // Update the post properties with the values from the form
                existingPost.Title = Post.Title;
                existingPost.CategoryId = Post.CategoryId;
                existingPost.PublicationDate = Post.PublicationDate;
                existingPost.Content = Post.Content;

                // Use the _postRepository to update the post
                await _postRepository.UpdatePostAsync(existingPost);

                // Redirect to the post list page after a successful update
                return RedirectToPage("Blog");
            }
            catch (Exception ex)
            {

                return Page();
            }
        }
    }

}
