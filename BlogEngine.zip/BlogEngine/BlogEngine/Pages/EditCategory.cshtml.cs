using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlogEngine.Models;
using BlogEngine.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlogEngine.Pages
{
    public class EditCategoryModel : PageModel
    {


        private readonly ICategoryRepository _categoryRepository;

        public EditCategoryModel(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        [BindProperty]
        public Category Category { get; set; }
        public int CategoryId { get; set; } // Ajoutez une propri�t� pour stocker le CategoryId

        public async Task<IActionResult> OnGet(int id)
        {
            Category = await _categoryRepository.GetCategoryByIdAsync(id);
            CategoryId = id; // Stockez la valeur du CategoryId
            return Page();
        }




        public async Task<IActionResult> OnPost()
        {
            // R�cup�rez le CategoryId de la requ�te
            if (int.TryParse(Request.Form["CategoryId"], out int categoryId))
            {
                try
                {
                    Category.CategoryId = categoryId;
                    var updateCategory = await _categoryRepository.UpdateCategoryAsync(Category);
                    return RedirectToPage("Blog"); // Redirect to the blog page
                }
                catch (InvalidOperationException ex)
                {
                    // Handle the duplicate category error
                    ModelState.AddModelError(string.Empty, ex.Message); // Add the error to ModelState
                    return Page(); // Return to the same page
                }
                catch (Exception ex)
                {
                    // Handle other exceptions, e.g., category not found or update failed
                   
                }
            }
            else
            {
                // G�rez l'erreur si le CategoryId n'est pas valide
                ModelState.AddModelError(string.Empty, "Invalid CategoryId");
                return Page();
            }

            // If there's an error or validation issue, return to the same page
            return Page();

        }


    }
}
