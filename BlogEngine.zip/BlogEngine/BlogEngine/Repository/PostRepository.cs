﻿using BlogEngine.Models;
using BlogEngine.Repository.Interfaces;
using BlogEngine.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlogEngine.Repository
{
    public class PostRepository : IPostRepository
    {
        private readonly ApiClient _apiClient;

        public PostRepository(ApiClient apiClient)
        {
            _apiClient = apiClient;
        }


        public async Task<List<Post>> GetPostsAsync()
        {
            return await _apiClient.GetAsync<List<Post>>("api/posts");
        }

        public async Task<Post> GetPostAsync(int postId)
        {
            return await _apiClient.GetAsync<Post>($"api/posts/{postId}");
        }

        public async Task<Post> AddPostAsync(Post post)
        {
            return await _apiClient.PostAsync("api/posts", post);
        }

        public async Task<Post> UpdatePostAsync(Post post)
        {
            return await _apiClient.PutAsync($"api/posts/{post.PostId}", post);
        }

        public async Task<bool> DeletePostAsync(int postId)
        {
            await _apiClient.DeleteAsync($"api/posts/{postId}");
            return true;
        }
    }
}
