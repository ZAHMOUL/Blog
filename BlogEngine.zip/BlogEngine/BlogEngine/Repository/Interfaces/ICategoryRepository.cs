﻿using BlogEngine.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlogEngine.Repository.Interfaces
{
    public interface ICategoryRepository
    {

        Task<Category> GetCategoryByIdAsync(int categoryId);
        Task<IEnumerable<Category>> GetCategoriesAsync();
        Task<Category> AddCategoryAsync(Category category);
        Task<Category> UpdateCategoryAsync(Category category);
        Task DeleteCategoryAsync(int categoryId);
    }
}
