﻿using BlogEngine.Models;
using BlogEngine.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text;
using Newtonsoft.Json;
using BlogEngine.Service;

namespace BlogEngine.Repository
{
    public class BlogRepository : IBlogRepository
    {
        private readonly ApiClient _apiClient;

        public BlogRepository(ApiClient apiClient)
        {
            _apiClient = apiClient;
        }

        public async Task<List<Category>> GetCategoriesAsync()
        {
            // Use the ApiClient to get a list of categories from the API
            return await _apiClient.GetAsync<List<Category>>("api/categories");
        }

        public async Task<Category> GetCategoryAsync(int categoryId)
        {
            // Use the ApiClient to get a specific category by ID from the API
            return await _apiClient.GetAsync<Category>($"api/categories/{categoryId}");
        }

        public async Task CreateCategoryAsync(Category category)
        {
            // Use the ApiClient to create a new category in the API
            await _apiClient.PostAsync("api/categories", category);
        }

        public async Task UpdateCategoryAsync(Category category)
        {
            // Use the ApiClient to update an existing category in the API
            await _apiClient.PutAsync($"api/categories/{category.CategoryId}", category);
        }

        public async Task DeleteCategoryAsync(int categoryId)
        {
            // Use the ApiClient to delete a category by ID in the API
            await _apiClient.DeleteAsync($"api/categories/{categoryId}");
        }

        public async Task<List<Post>> GetPostsAsync()
        {
            // Use the ApiClient to get a list of posts from the API
            return await _apiClient.GetAsync<List<Post>>("api/posts");
        }

        public async Task<Post> GetPostAsync(int postId)
        {
            // Use the ApiClient to get a specific post by ID from the API
            return await _apiClient.GetAsync<Post>($"api/posts/{postId}");
        }

        public async Task CreatePostAsync(Post post)
        {
            // Use the ApiClient to create a new post in the API
            await _apiClient.PostAsync("api/posts", post);
        }

        public async Task UpdatePostAsync(Post post)
        {
            // Use the ApiClient to update an existing post in the API
            await _apiClient.PutAsync($"api/posts/{post.PostId}", post);
        }

        public async Task DeletePostAsync(int postId)
        {
            // Use the ApiClient to delete a post by ID in the API
            await _apiClient.DeleteAsync($"api/posts/{postId}");
        }
    }

}
