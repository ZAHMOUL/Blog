﻿using BlogEngine.Models;
using BlogEngine.Repository.Interfaces;
using BlogEngine.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlogEngine.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly ApiClient _apiClient;

        public CategoryRepository(ApiClient apiClient)
        {
            _apiClient = apiClient;
        }

        public async Task<IEnumerable<Category>> GetCategoriesAsync()
        {
            return await _apiClient.GetAsync<IEnumerable<Category>>("api/categories");
        }

        public async Task<Category> AddCategoryAsync(Category category)
        {
            var existingCategories = await GetCategoriesAsync();

            // Check for duplicate category titles (case-insensitive comparison)
            var duplicateCategory = existingCategories.FirstOrDefault(c =>
    string.Equals(c.Title.Trim(), category.Title.Trim(), StringComparison.OrdinalIgnoreCase));

            if (duplicateCategory != null)
            {
                // Throw an exception or handle the duplicate category error as needed
                throw new InvalidOperationException("Category with the same title already exists.");
            }

            // Continue with adding the new category
            return await _apiClient.PostAsync<Category>("api/categories", category);
        }


        public async Task<Category> UpdateCategoryAsync(Category category)
        {
            // Check for duplicate category titles (case-insensitive comparison)
            var existingCategories = await GetCategoriesAsync();
            var duplicateCategory = existingCategories.FirstOrDefault(c =>
                string.Equals(c.Title.Trim(), category.Title.Trim(), StringComparison.OrdinalIgnoreCase) && c.CategoryId != category.CategoryId);

            if (duplicateCategory != null)
            {
                throw new InvalidOperationException("Category with the same title already exists.");
            }

            // Continue with the update if there's no duplication
            var uri = $"api/categories/{category.CategoryId}";

            return await _apiClient.PutAsync(uri, category);
        }

        public async Task<Category> GetCategoryByIdAsync(int categoryId)
        {
            // Make an API call to get the category by ID
            var category = await _apiClient.GetAsync<Category>($"api/categories/{categoryId}");

            return category;
        }


        public async Task DeleteCategoryAsync(int categoryId)
        {
            await _apiClient.DeleteAsync($"api/categories/{categoryId}");
        }
    }
}
