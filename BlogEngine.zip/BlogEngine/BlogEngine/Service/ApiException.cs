﻿using System;
using System.Runtime.Serialization;

namespace BlogEngine.Service
{
    public class ApiException : Exception
    {
        public int StatusCode { get; }
        public string Content { get; }

        public ApiException(int statusCode)
        {
            StatusCode = statusCode;
        }

        public ApiException(int statusCode, string message) : base(message)
        {
            StatusCode = statusCode;
        }

        public ApiException(int statusCode, string message, Exception innerException) : base(message, innerException)
        {
            StatusCode = statusCode;
        }

        public ApiException(int statusCode, string content, string message) : base(message)
        {
            StatusCode = statusCode;
            Content = content;
        }

        public ApiException(int statusCode, string content, string message, Exception innerException) : base(message, innerException)
        {
            StatusCode = statusCode;
            Content = content;
        }
    }




}