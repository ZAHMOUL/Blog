﻿namespace BlogEngine.Service
{
    public class ErrorResponse
    {
        public string ErrorMessage { get; set; }
        // Add more properties as needed to represent the error response structure
    }

}