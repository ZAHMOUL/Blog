﻿using BlogEngineAPI.DataModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlogEngineAPI.Controllers
{
    [Route("api/posts")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly BlogDbContext _context;

        public PostController(BlogDbContext context)
        {
            _context = context;
        }

        // GET: api/posts
        [HttpGet]
        public IActionResult Get()
        {
            var posts = _context.Posts.ToList(); // Assuming you have a DbSet for Posts in your DbContext
            return Ok(posts);
        }

        // GET: api/posts/{id}
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var post = _context.Posts.Find(id);
            if (post == null)
            {
                return NotFound(); // Return a 404 Not Found if the post is not found
            }
            return Ok(post);
        }

        // POST: api/posts
        [HttpPost]
        public IActionResult Post([FromBody] Post post)
        {
            if (post == null)
            {
                return BadRequest(); // Return a 400 Bad Request if the request body is empty
            }

            _context.Posts.Add(post);
            _context.SaveChanges();

            return CreatedAtAction("Get", new { id = post.PostId }, post); // Return a 201 Created status with the newly created post
        }

        // PUT: api/posts/{id}
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Post post)
        {
            if (post == null || id != post.PostId)
            {
                return BadRequest(); // Return a 400 Bad Request if the request body is empty or the ID doesn't match
            }

            var existingPost = _context.Posts.Find(id);
            if (existingPost == null)
            {
                return NotFound(); // Return a 404 Not Found if the post is not found
            }

            existingPost.Title = post.Title; // Update properties as needed
            existingPost.Content = post.Content;

            _context.Posts.Update(existingPost);
            _context.SaveChanges();

            return NoContent(); // Return a 204 No Content upon successful update
        }

        // DELETE: api/posts/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var post = _context.Posts.Find(id);
            if (post == null)
            {
                return NotFound(); // Return a 404 Not Found if the post is not found
            }

            _context.Posts.Remove(post);
            _context.SaveChanges();

            return NoContent(); // Return a 204 No Content upon successful deletion
        }
    }
}
