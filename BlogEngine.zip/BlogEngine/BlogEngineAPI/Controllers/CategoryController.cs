﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlogEngineAPI.Controllers
{
    using BlogEngineAPI.DataModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;

    [Route("api/categories")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly BlogDbContext _context;

        public CategoryController(BlogDbContext context)
        {
            _context = context;
        }

        // GET: api/categories
        [HttpGet]
        public IActionResult Get()
        {
            var categories = _context.Categories.ToList(); // Assuming you have a DbSet for Categories in your DbContext
            return Ok(categories);
        }

        // GET: api/categories/{id}
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var category = _context.Categories.Find(id);
            if (category == null)
            {
                return NotFound(); // Return a 404 Not Found if the category is not found
            }
            return Ok(category);
        }

        // POST: api/categories
        [HttpPost]
        public IActionResult Post([FromBody] Category category)
        {
            if (category == null)
            {
                return BadRequest(); // Return a 400 Bad Request if the request body is empty
            }

            _context.Categories.Add(category);
            _context.SaveChanges();

            return CreatedAtAction("Get", new { id = category.CategoryId }, category); // Return a 201 Created status with the newly created category
        }

        // PUT: api/categories/{id}
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Category category)
        {
            if (category == null || id != category.CategoryId)
            {
                return BadRequest(); // Return a 400 Bad Request if the request body is empty or the ID doesn't match
            }

            var existingCategory = _context.Categories.Find(id);
            if (existingCategory == null)
            {
                return NotFound(); // Return a 404 Not Found if the category is not found
            }

            existingCategory.Title = category.Title; // Update properties as needed

            _context.Categories.Update(existingCategory);
            _context.SaveChanges();

            return NoContent(); // Return a 204 No Content upon successful update
        }

        // DELETE: api/categories/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var category = _context.Categories.Find(id);
            if (category == null)
            {
                return NotFound(); // Return a 404 Not Found if the category is not found
            }

            _context.Categories.Remove(category);
            _context.SaveChanges();

            return NoContent(); // Return a 204 No Content upon successful deletion
        }
    }

}
