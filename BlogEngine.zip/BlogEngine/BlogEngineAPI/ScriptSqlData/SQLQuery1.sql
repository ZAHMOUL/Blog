-- Insert data into the Categories table
INSERT INTO Categories (Title)
VALUES
    ('Technology'),
    ('Travel'),
    ('Food');

-- Insert data into the Posts table
INSERT INTO Posts (Title,  PublicationDate,Content, CategoryID)
VALUES
    ('Introduction to Blogging', '2023-10-20', 'Blogging is a great way to share your thoughts...', 1),
    ('10 Must-Visit Destinations', '2023-10-21', 'Here are 10 incredible destinations to explore...', 2),
    ('Delicious Recipes from Around the World','2023-10-22', 'Explore the flavors of different cuisines with these recipes...',  3);
